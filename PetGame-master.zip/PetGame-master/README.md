<h2> #PetGame </h2>
<h1> Summer 2015 </h1>

<p> A play of one of my favorite childhood games "tamogochi". 
I wanted to see if I could create a text base game that mirrors 
the actions of getting, feeding and playing with a pet in order to keep
up the pet's health and happiness.

Created to be used as an example during teaching summer iDTech Camp at Alexa Cafe. </p> 
